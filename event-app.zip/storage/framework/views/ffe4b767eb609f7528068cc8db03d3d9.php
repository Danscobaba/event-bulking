<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;500;600;700;800;900&display=swap"
          rel="stylesheet">
    <title>Regiastration Success</title>
    <style>

        .receipt {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .header h1 {
            color: #333;
        }

        .details {
            margin-bottom: 20px;
        }

        .details p {
            margin: 5px 0;
            font-size: 14px;
            color: #555;
        }

        .items {
            border-top: 1px solid #ddd;
            border-bottom: 1px solid #ddd;
            margin-bottom: 20px;
            padding: 10px 0;
        }

        .item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .item span {
            flex: 1;
        }

        .total {
            display: flex;
            justify-content: space-between;
            font-weight: bold;
        }

        .total span {
            flex: 1;
        }

        .thank-you {
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
            color: #333;
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.js"></script>
</head>
<body>
<?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss']); ?>
<div class="hero-section" style="height: 100vh">
    <div class="hero-section-two">
        <img class="ellipse-first" src="<?php echo e(asset('img/Ellipse.svg')); ?>" alt="">
        <img class="ellipse-second" src="<?php echo e(asset('img/Ellipse.svg')); ?>" alt="">
        <img class="ring1" src="<?php echo e(asset('img/ring.svg')); ?>" alt="">
        <img class="ring2" src="<?php echo e(asset('img/ring.svg')); ?>" alt="">
        <img class="ring3" src="<?php echo e(asset('img/ring.svg')); ?>" alt="">
        <img class="ring4" src="<?php echo e(asset('img/ring.svg')); ?>" alt="">

        <div class="logo">
            <img onclick="location.href='<?php echo e(url('/')); ?>'" src="<?php echo e(asset('img/logo.png')); ?>" alt="">
        </div>
        <div class="container">
            <div class="card">
                <h3 class="head">Registration Completed</h3>
                <p>Congratulations, You have successfully registered for the 2023 Faitheroic Global (Ignite) Team Directors Dinner and you have successfully made a payment of [amount]</p>
                <p>Below are your payment details</p>
                <p><strong>Amount:</strong> [Amount]</p>
                <p><strong>Amount:</strong> [Amount]</p>
                <div class="btn-print">
                    <button onclick="convertToPdf()">Print Receipt</button>
                </div>

            </div>

        </div>

    </div>

<script>
    // Function to convert HTML content to PDF
    function convertToPdf() {
        var element = document.getElementById('pdfContent');
        // html2pdf(element);
        var opt = {
            margin:       1,
            filename:     'myfile.pdf',
            image:        { type: 'png', quality: 1 },
            html2canvas:  { scale: 1 },
            jsPDF:        { unit: 'in', format: 'a5', orientation: 'portrait' }
        };

// New Promise-based usage:
        html2pdf().set(opt).from(element).save();
    }
</script>
</body>
</html>
<?php /**PATH C:\Users\akiny\Documents\project\ayobami\event-app\resources\views/success.blade.php ENDPATH**/ ?>