<?php $__env->startSection('master-admin'); ?>
    <div class="card p-3" style="overflow: auto">
        <?php
            $data = DB::table('member')->get();
        ?>
        <div class="table-responsive-lg">
            <table class="table table-striped table-responsive-lg">
                <thead>
                    <tr class="text-center">
                        <th>S/No.</th>
                        <th style="min-width: 120px">Full Name</th>
                        <th style="min-width: 120px">Email Address</th>
                        <th style="min-width: 120px">Phone No.</th>
                        <th style="min-width: 70px">Gender</th>
                        <th style="min-width: 120px">Status</th>
                        <th style="min-width: 120px">Amount Paid</th>
                        <th style="min-width: 120px">Transaction Id</th>
                        <th style="min-width: 120px">Reference Id</th>
                        <th style="min-width: 120px">Date Register</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($item->full_name); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td><?php echo e($item->phone_no); ?></td>
                            <td style="text-transform: capitalize"><?php echo e($item->gender); ?></td>
                            <td><?php echo e($item->status); ?></td>
                            <td>N<?php echo e($item->amount); ?>.00</td>
                            <td><?php echo e($item->transaction_id); ?></td>
                            <td><?php echo e($item->reference_id); ?></td>
                            <td><?php echo e($item->created_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\akiny\Documents\project\ayobami\event-app\resources\views/dashboard.blade.php ENDPATH**/ ?>